import sys, json
from pathlib import Path
from graphify.extract import collect_files, extract
from graphify.build import build_from_json
from graphify.cluster import cluster, score_all
from graphify.analyze import god_nodes, surprising_connections, suggest_questions
from graphify.report import generate
from graphify.export import to_json, to_html

out_dir = Path("graphify-out")
out_dir.mkdir(exist_ok=True)

print("1. AST Direct Extraction (Skip LLM Semantic Tooling)")
from graphify.detect import detect
detect_res = detect(Path('.'))
(out_dir / ".graphify_detect.json").write_text(json.dumps(detect_res))

code_files = []
for f in detect_res.get("files", {}).get("code", []):
    fp = Path(f)
    if fp.exists():
        code_files.extend(collect_files(fp) if fp.is_dir() else [fp])

ast_res = extract(code_files) if code_files else {"nodes":[], "edges":[], "input_tokens":0, "output_tokens":0}

merged = {
    "nodes": ast_res["nodes"],
    "edges": ast_res["edges"],
    "hyperedges": [],
    "input_tokens": 0, "output_tokens": 0,
}
(out_dir / ".graphify_extract.json").write_text(json.dumps(merged, indent=2))

print("2. Build & Generate")
G = build_from_json(merged)
if G.number_of_nodes() == 0:
    print("Graph empty. Check .graphifyignore rules.")
    sys.exit(1)

communities = cluster(G)
cohesion = score_all(G, communities)
gods = god_nodes(G)
surprises = surprising_connections(G, communities)
labels = {cid: f'Community {cid}' for cid in communities}

print("3. Export to JSON, HTML, Markdown")
to_json(G, communities, out_dir / "graph.json")
to_html(G, communities, out_dir / "graph.html", community_labels=labels)
report = generate(G, communities, cohesion, labels, gods, surprises, detect_res, {"input":0,"output":0}, str(Path('.').absolute()))
(out_dir / "GRAPH_REPORT.md").write_text(report, encoding="utf-8")

print(f"Zero-Token Graph Completed! {G.number_of_nodes()} Nodes, {G.number_of_edges()} Edges.")
